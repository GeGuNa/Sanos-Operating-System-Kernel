#define CONFIG_TCCDIR "/usr"
#define GCC_MAJOR 2
#define HOST_I386 1
#define CONFIG_WIN32 1
#define TCC_VERSION "0.9.24"
#define TCC_TARGET_PE 
#undef _WIN32
