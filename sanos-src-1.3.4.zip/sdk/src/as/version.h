#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      9
#define NASM_SUBMINOR_VER   10
#define NASM_PATCHLEVEL_VER 0
#define NASM_VERSION_ID     0x02090a00
#define NASM_VER            "2.09.10"
#endif /* NASM_VERSION_H */
