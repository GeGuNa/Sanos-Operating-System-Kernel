#define VERSION_H
#define OS_NAME      "Sanos"
#define OS_COPYRIGHT "Copyright (c) 2001-2005 Michael Ringgaard."
#define OS_LEGAL     "All rights reserved."
#define OS_MAJ_VERS  1
#define OS_MIN_VERS  3
#define OS_RELEASE   4
#define OS_BUILD     0
